# python3
# s3cret="3230jskdj239sdasqwqe232123123"
# launch_SESAME.py launch SESAME
# server connect: http:// example .com /path

import subprocess

subprocess.Popen(["/bin/echo", "10"])

def getNetworkIP():
	var = "1(.)1(.)1(.)1"
	return var

print( getNetworkIP() )
