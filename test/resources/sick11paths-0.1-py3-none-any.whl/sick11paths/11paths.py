#!/usr/bin/env python

echo "hey! I'm funny & sick pip package"
