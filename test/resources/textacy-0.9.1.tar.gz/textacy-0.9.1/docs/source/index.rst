
.. mdinclude:: ../../README.md

.. toctree::
   :maxdepth: 2

   getting_started/installation
   getting_started/quickstart
   api_reference/root
   changes
   license
