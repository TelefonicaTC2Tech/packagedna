.. _api-reference:

*************
API Reference
*************

.. toctree::
   :maxdepth: 2

   lang_doc_corpus
   spacier
   datasets
   resources
   text_processing
   information_extraction
   vsm_and_tm
   io
   viz
   augmentation
   utils
   misc
