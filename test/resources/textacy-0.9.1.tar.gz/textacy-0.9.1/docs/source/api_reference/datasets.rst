.. _api-reference-datasets:

Datasets
========

.. automodule:: textacy.datasets.capitol_words

.. automodule:: textacy.datasets.supreme_court

.. automodule:: textacy.datasets.wikimedia

.. automodule:: textacy.datasets.reddit_comments

.. automodule:: textacy.datasets.oxford_text_archive

.. automodule:: textacy.datasets.imdb

.. automodule:: textacy.datasets.udhr

.. automodule:: textacy.datasets.utils
