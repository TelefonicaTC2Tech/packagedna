.. _api-reference-lang-doc-corpus:

Lang, Doc, Corpus
=================

.. automodule:: textacy.spacier.core

.. automodule:: textacy.corpus
