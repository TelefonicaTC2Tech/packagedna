.. _ref-api-reference-io:

IO
==

.. automodule:: textacy.io.text

.. automodule:: textacy.io.json

.. automodule:: textacy.io.csv

.. automodule:: textacy.io.matrix

.. automodule:: textacy.io.spacy

.. automodule:: textacy.io.http

.. automodule:: textacy.io.utils
