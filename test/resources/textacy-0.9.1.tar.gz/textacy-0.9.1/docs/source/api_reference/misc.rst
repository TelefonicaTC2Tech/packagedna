.. _ref-api-reference-misc:

Miscellany
==========

.. automodule:: textacy.text_stats

.. automodule:: textacy.network

.. automodule:: textacy.similarity
