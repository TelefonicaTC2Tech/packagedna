.. _ref-api-reference-augmentation:

Data Augmentation
=================

.. automodule:: textacy.augmentation.augmenter

.. automodule:: textacy.augmentation.transforms

.. automodule:: textacy.augmentation.utils
