.. _ref-api-reference-information-extraction:

Information Extraction
======================

.. automodule:: textacy.extract

Keyterm Extraction
------------------

.. automodule:: textacy.ke.textrank

.. automodule:: textacy.ke.yake

.. automodule:: textacy.ke.scake

.. automodule:: textacy.ke.sgrank

.. automodule:: textacy.ke.utils
