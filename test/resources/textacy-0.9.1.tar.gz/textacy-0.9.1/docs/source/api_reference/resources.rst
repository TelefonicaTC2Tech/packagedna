.. _api-reference-resources:

Resources
=========

.. automodule:: textacy.resources.concept_net

.. automodule:: textacy.resources.depeche_mood
