.. _ref-api-reference-utils:

Utilities
=========

.. automodule:: textacy.lang_utils

.. automodule:: textacy.cache
