.. _ref-api-reference-vsm-and-tm:

Vectorization & Topic Modeling
==============================

.. automodule:: textacy.vsm.vectorizers

.. automodule:: textacy.vsm.matrix_utils

.. automodule:: textacy.tm.topic_model
