.. _api-reference-spacier:

spaCy extensions
================

.. automodule:: textacy.spacier.doc_extensions

.. automodule:: textacy.spacier.components

.. automodule:: textacy.spacier.utils
